"""Probe Granian's embedded mode: can one process run an HTTP and an HTTPS listener?

Granian is normally started from its CLI (one listener per process). Recent versions ship an
experimental ``granian.server.embed.Server`` that runs inside an existing asyncio loop. This
probe introspects it, tries to start two servers (HTTP + HTTPS) in one loop, sends one request
to each and prints a JSON report on stdout. It never raises: every failure is reported.

Usage: python probe_granian_embed.py CERTS_DIR HTTP_PORT HTTPS_PORT
"""

from __future__ import annotations

import asyncio
import http.client
import inspect
import json
import ssl
import sys
from pathlib import Path
from typing import Any

from app import app


def _request(port: int, https: bool, certs: Path) -> dict[str, Any]:
    try:
        if https:
            ctx = ssl.create_default_context(cafile=str(certs / "root.pem"))
            ctx.load_cert_chain(str(certs / "client.pem"), str(certs / "client.key"))
            conn: http.client.HTTPConnection = http.client.HTTPSConnection("127.0.0.1", port, context=ctx, timeout=5)
        else:
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request("GET", "/whoami")
        resp = conn.getresponse()
        body = json.loads(resp.read() or b"{}")
        conn.close()
        return {"status": resp.status, "body": body}
    except Exception as exc:  # noqa: BLE001 - report everything
        return {"error": repr(exc)}


async def main(certs: Path, http_port: int, https_port: int) -> dict[str, Any]:
    report: dict[str, Any] = {}
    try:
        import granian
        from granian.server.embed import Server  # type: ignore[import-not-found]
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "error": repr(exc)}

    report["granian_version"] = getattr(granian, "__version__", "?")
    params = list(inspect.signature(Server.__init__).parameters)
    report["available"] = True
    report["embed_params"] = params

    try:
        from granian.constants import Interfaces  # type: ignore[import-not-found]

        interface: Any = Interfaces.ASGI
    except Exception:  # noqa: BLE001
        interface = "asgi"

    def kwargs_for(port: int, https: bool) -> dict[str, Any]:
        kw: dict[str, Any] = {}
        if "address" in params:
            kw["address"] = "127.0.0.1"
        elif "host" in params:
            kw["host"] = "127.0.0.1"
        kw["port"] = port
        if "interface" in params:
            kw["interface"] = interface
        if https:
            for name in ("ssl_cert", "ssl_certificate"):
                if name in params:
                    kw[name] = certs / "server.pem"
            for name in ("ssl_key", "ssl_keyfile"):
                if name in params:
                    kw[name] = certs / "server.key"
            if "ssl_ca" in params:
                kw["ssl_ca"] = certs / "root.pem"
            for name in ("ssl_client_verify",):
                if name in params:
                    kw[name] = True
        return kw

    servers: list[Any] = []
    tasks: list[asyncio.Task[Any]] = []
    try:
        for port, https in ((http_port, False), (https_port, True)):
            kw = kwargs_for(port, https)
            report[f"{'https' if https else 'http'}_kwargs"] = {k: str(v) for k, v in kw.items()}
            server = Server(app, **kw)
            servers.append(server)
            tasks.append(asyncio.create_task(server.serve()))
        await asyncio.sleep(3)
        report["http_request"] = await asyncio.to_thread(_request, http_port, False, certs)
        report["https_request"] = await asyncio.to_thread(_request, https_port, True, certs)
    except Exception as exc:  # noqa: BLE001
        report["start_error"] = repr(exc)
    finally:
        for server in servers:
            stop = getattr(server, "stop", None)
            try:
                if stop is not None:
                    result = stop()
                    if inspect.isawaitable(result):
                        await result
            except Exception as exc:  # noqa: BLE001
                report.setdefault("stop_errors", []).append(repr(exc))
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    return report


if __name__ == "__main__":
    import os

    os.environ.setdefault("SPIKE_SERVER", "granian-embed")
    result = asyncio.run(main(Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])))
    print(json.dumps(result, default=str))

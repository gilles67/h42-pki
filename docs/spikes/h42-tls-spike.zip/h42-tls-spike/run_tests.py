"""Run every scenario of the spike and print a Markdown report.

Uvicorn scenarios (U*) check the home-made launcher; they are expected to pass and make the exit
code non-zero if they do not. Granian scenarios (G*) are *observations*: they answer "what does
Granian do?" and never fail the run. They are skipped when Granian is not installed.

Usage: python run_tests.py [--report results.md] [--keep]
"""

from __future__ import annotations

import argparse
import http.client
import json
import os
import platform
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pki

HERE = Path(__file__).resolve().parent


# --- helpers -----------------------------------------------------------------------------------


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def port_open(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def wait_port(port: int, timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if port_open(port):
            return True
        time.sleep(0.1)
    return False


@dataclass
class Answer:
    status: int | None = None
    body: dict[str, Any] | None = None
    peer_serial: str | None = None
    error: str | None = None


def client_context(certs: Path, client: str | None) -> ssl.SSLContext:
    ctx = ssl.create_default_context(cafile=str(certs / "root.pem"))
    if client:
        ctx.load_cert_chain(str(certs / f"{client}.pem"), str(certs / f"{client}.key"))
    return ctx


def request(port: int, path: str, *, https: bool, certs: Path, client: str | None = None,
            conn: http.client.HTTPConnection | None = None) -> tuple[Answer, http.client.HTTPConnection | None]:
    """GET ``path``; returns the answer and the (kept-alive) connection."""
    try:
        if conn is None:
            if https:
                conn = http.client.HTTPSConnection("127.0.0.1", port, context=client_context(certs, client), timeout=5)
            else:
                conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request("GET", path)
        resp = conn.getresponse()
        raw = resp.read()
        answer = Answer(status=resp.status, body=json.loads(raw) if raw else None)
        sock = conn.sock
        if https and isinstance(sock, ssl.SSLSocket):
            der = sock.getpeercert(binary_form=True)
            if der:
                from cryptography import x509

                answer.peer_serial = format(x509.load_der_x509_certificate(der).serial_number, "x")
        return answer, conn
    except Exception as exc:  # noqa: BLE001 - a refused handshake is an expected outcome
        if conn is not None:
            conn.close()
        return Answer(error=f"{type(exc).__name__}: {exc}"), None


class Report:
    def __init__(self) -> None:
        self.rows: list[tuple[str, str, str, str]] = []

    def add(self, ident: str, title: str, status: str, detail: str) -> None:
        self.rows.append((ident, title, status, detail))
        print(f"[{status:4}] {ident} {title} -- {detail}", flush=True)

    def check(self, ident: str, title: str, ok: bool, detail: str) -> None:
        self.add(ident, title, "PASS" if ok else "FAIL", detail)

    def failed(self, prefix: str) -> bool:
        return any(r[0].startswith(prefix) and r[2] == "FAIL" for r in self.rows)

    def markdown(self, header: str) -> str:
        lines = [header, "", "| # | Scénario | Résultat | Détail |", "|---|---|---|---|"]
        for ident, title, status, detail in self.rows:
            detail = detail.replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {ident} | {title} | {status} | {detail} |")
        return "\n".join(lines) + "\n"


def tls_of(answer: Answer) -> dict[str, Any] | None:
    if not answer.body:
        return None
    tls = answer.body.get("tls")
    return tls if isinstance(tls, dict) else None


def start(cmd: list[str], log_path: Path, env_extra: dict[str, str]) -> subprocess.Popen[bytes]:
    env = {**os.environ, **env_extra, "PYTHONUNBUFFERED": "1"}
    log = open(log_path, "wb")  # noqa: SIM115 - closed with the process
    return subprocess.Popen(cmd, cwd=HERE, env=env, stdout=log, stderr=subprocess.STDOUT)


def stop(proc: subprocess.Popen[bytes], timeout: float = 8.0) -> bool:
    """Ask for a clean shutdown; return True if the process exited in time."""
    if proc.poll() is not None:
        return True
    proc.send_signal(signal.SIGTERM if os.name != "nt" else signal.CTRL_BREAK_EVENT)
    try:
        proc.wait(timeout=timeout)
        return True
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        return False


# --- Uvicorn: home-made launcher ---------------------------------------------------------------


def uvicorn_scenarios(work: Path, report: Report) -> None:
    certs = work / "uvicorn-certs"
    pki.init(certs, with_server=False)
    http_port, https_port = free_port(), free_port()
    proc = start(
        [sys.executable, "launcher_uvicorn.py", "--certs", str(certs), "--http-port", str(http_port),
         "--https-port", str(https_port), "--wait-for-cert", "--reload-interval", "0.5"],
        work / "uvicorn.log",
        {"SPIKE_SERVER": "uvicorn"},
    )
    try:
        report.check("U1", "HTTP démarre seul, avant tout certificat serveur", wait_port(http_port),
                     f"port {http_port}")
        time.sleep(1.5)
        report.check("U2", "HTTPS fermé tant qu'il n'y a pas de certificat", not port_open(https_port),
                     f"port {https_port} fermé")

        first = pki.issue_server(certs)
        first_serial = format(first.serial_number, "x")
        up = wait_port(https_port, 10)
        report.check("U3", "HTTPS démarre dès que le certificat existe (sans redémarrage)", up,
                     f"certificat {first_serial[:12]}…")

        a, _ = request(http_port, "/whoami", https=False, certs=certs)
        ok = a.status == 200 and a.body is not None and a.body.get("scheme") == "http" and tls_of(a) is None
        report.check("U4", "HTTP : schéma http, pas d'extension tls", ok, json.dumps(a.body or a.error))

        a, _ = request(http_port, "/admin", https=False, certs=certs)
        report.check("U5", "Séparation des routes : /admin refusé en HTTP", a.status == 404, f"status {a.status}")

        a, _ = request(https_port, "/admin", https=True, certs=certs)
        report.check("U6", "Séparation des routes : /admin servi en HTTPS", a.status == 200, f"status {a.status}")

        a, _ = request(https_port, "/whoami", https=True, certs=certs)
        tls = tls_of(a)
        ok = a.status == 200 and tls is not None and tls.get("client_cert_name") is None
        report.check("U7", "HTTPS sans certificat client accepté (mTLS optionnel)", ok, json.dumps(tls or a.error))

        a, _ = request(https_port, "/whoami", https=True, certs=certs, client="client")
        tls = tls_of(a)
        name = tls.get("client_cert_name") if tls else None
        ok = a.status == 200 and name == "CN=spike-client"
        report.check("U8", "Certificat client de confiance visible dans scope['extensions']['tls']", ok,
                     json.dumps(tls or a.error))
        chain = tls.get("client_cert_chain") if tls else None
        expected = "2 certificate(s)" if sys.version_info >= (3, 13) else "1 certificate(s)"
        report.check("U9", "Chaîne vérifiée du client transmise (Python ≥ 3.13 : feuille + AC)",
                     chain == expected, f"{chain} (Python {platform.python_version()})")

        a, _ = request(https_port, "/whoami", https=True, certs=certs, client="rogue-client")
        report.check("U10", "Certificat client d'une AC inconnue refusé", a.status is None, a.error or f"status {a.status}")

        # hot reload: a kept-alive connection opened before the reload keeps working
        a, kept = request(https_port, "/whoami", https=True, certs=certs)
        before = a.peer_serial
        second = pki.issue_server(certs)
        second_serial = format(second.serial_number, "x")
        seen = None
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            b, _ = request(https_port, "/whoami", https=True, certs=certs)
            seen = b.peer_serial
            if seen == second_serial:
                break
            time.sleep(0.3)
        report.check("U11", "Renouvellement à chaud : les nouvelles connexions reçoivent le nouveau certificat",
                     before == first_serial and seen == second_serial,
                     f"{(before or '?')[:12]}… → {(seen or '?')[:12]}…")
        if kept is not None:
            c, _ = request(https_port, "/whoami", https=True, certs=certs, conn=kept)
            report.check("U12", "Une connexion ouverte avant le renouvellement continue de fonctionner",
                         c.status == 200, f"status {c.status} {c.error or ''}".strip())
            kept.close()

        report.check("U13", "Les deux ports sont servis par un seul processus", proc.poll() is None,
                     f"pid {proc.pid}")
    finally:
        clean = stop(proc)
        report.check("U14", "Arrêt propre des deux serveurs sur SIGTERM", clean, "")


# --- Granian: observations ---------------------------------------------------------------------


def granian_command() -> list[str] | None:
    exe = shutil.which("granian")
    if exe:
        return [exe]
    try:
        import granian  # noqa: F401
    except ImportError:
        return None
    return [sys.executable, "-m", "granian"]


def granian_scenarios(work: Path, report: Report) -> None:
    cmd = granian_command()
    if cmd is None:
        report.add("G0", "Granian installé", "SKIP", "granian absent : lancer le spike dans Docker (voir README)")
        return
    import granian

    report.add("G0", "Granian installé", "INFO", f"version {getattr(granian, '__version__', '?')}")
    certs = work / "granian-certs"
    pki.init(certs, with_server=True)

    def run_granian(verify: bool, label: str) -> tuple[subprocess.Popen[bytes], int]:
        port = free_port()
        args = cmd + ["--interface", "asgi", "--host", "127.0.0.1", "--port", str(port),
                      "--ssl-certificate", str(certs / "server.pem"), "--ssl-keyfile", str(certs / "server.key")]
        if verify:
            args += ["--ssl-ca", str(certs / "root.pem"), "--ssl-client-verify"]
        args += ["app:app"]
        proc = start(args, work / f"granian-{label}.log", {"SPIKE_SERVER": "granian"})
        if not wait_port(port, 15):
            log = (work / f"granian-{label}.log").read_text(errors="replace")[-500:]
            report.add(f"G-{label}", "Démarrage de Granian", "FAIL", f"port {port} jamais ouvert : {log}")
        return proc, port

    proc, port = run_granian(True, "verify")
    try:
        a, _ = request(port, "/whoami", https=True, certs=certs)
        report.add("G1", "--ssl-client-verify : connexion SANS certificat client", "INFO",
                   "acceptée (vérification optionnelle)" if a.status == 200
                   else f"refusée (certificat client obligatoire) : {a.error}")
        a, _ = request(port, "/whoami", https=True, certs=certs, client="client")
        tls = tls_of(a)
        if a.status == 200:
            exposed = bool(tls and tls.get("client_cert_name") or tls and tls.get("client_cert_chain"))
            report.add("G2", "Certificat client de confiance : visible par l'application ?",
                       "OUI" if exposed else "NON",
                       f"extensions={a.body.get('extension_keys') if a.body else None} tls={json.dumps(tls)}")
            report.add("G2b", "Clés du scope ASGI fournies par Granian", "INFO",
                       ", ".join(a.body.get("scope_keys", [])) if a.body else "")
        else:
            report.add("G2", "Certificat client de confiance : visible par l'application ?", "INFO",
                       f"requête échouée : {a.error or a.status}")
        a, _ = request(port, "/whoami", https=True, certs=certs, client="rogue-client")
        report.check("G3", "--ssl-client-verify : certificat d'une AC inconnue refusé", a.status is None,
                     a.error or f"status {a.status}")
    finally:
        stop(proc)

    proc, port = run_granian(False, "noverify")
    try:
        a, _ = request(port, "/whoami", https=True, certs=certs, client="client")
        tls = tls_of(a)
        report.add("G4", "Sans --ssl-client-verify, certificat client présenté : visible ?", "INFO",
                   f"status {a.status} tls={json.dumps(tls)} {a.error or ''}".strip())
    finally:
        stop(proc)

    p1, p2 = free_port(), free_port()
    try:
        out = subprocess.run([sys.executable, "probe_granian_embed.py", str(certs), str(p1), str(p2)],
                             cwd=HERE, capture_output=True, text=True, timeout=60)
        text = out.stdout.strip().splitlines()[-1] if out.stdout.strip() else out.stderr[-500:]
        try:
            probe = json.loads(text)
        except json.JSONDecodeError:
            probe = {"raw": text}
    except subprocess.TimeoutExpired:
        probe = {"error": "timeout"}
    both = (isinstance(probe.get("http_request"), dict) and probe["http_request"].get("status") == 200
            and isinstance(probe.get("https_request"), dict) and probe["https_request"].get("status") == 200)
    report.add("G5", "Mode embarqué : HTTP + HTTPS dans un seul processus", "OUI" if both else "NON/INCONNU",
               json.dumps(probe, default=str)[:900])


# --- main --------------------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--report", type=Path, default=None, help="write the Markdown report to this file")
    parser.add_argument("--keep", action="store_true", help="keep the temporary directory (logs, certs)")
    args = parser.parse_args()

    work = Path(tempfile.mkdtemp(prefix="h42-tls-spike-"))
    report = Report()
    try:
        import uvicorn

        print(f"Python {platform.python_version()} - uvicorn {uvicorn.__version__} - work dir {work}")
        uvicorn_scenarios(work, report)
        granian_scenarios(work, report)
    finally:
        if not args.keep:
            shutil.rmtree(work, ignore_errors=True)

    import cryptography
    import uvicorn

    header = (
        "# Résultats du spike TLS\n\n"
        f"- Date : {time.strftime('%Y-%m-%d %H:%M:%S %Z')}\n"
        f"- Python {platform.python_version()} ({platform.system()}), uvicorn {uvicorn.__version__}, "
        f"cryptography {cryptography.__version__}"
    )
    md = report.markdown(header)
    print()
    print(md)
    if args.report:
        args.report.write_text(md, encoding="utf-8")
    return 1 if report.failed("U") else 0


if __name__ == "__main__":
    sys.exit(main())

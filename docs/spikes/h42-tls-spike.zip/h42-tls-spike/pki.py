"""Throw-away test PKI for the TLS spike.

Creates, in a directory (default ``certs/``):

- ``root.pem`` / ``root.key``                 trusted CA
- ``server.pem`` / ``server.key``             server certificate signed by the trusted CA
                                              (SAN: localhost, 127.0.0.1), plus ``server.version``
- ``client.pem`` / ``client.key``             client certificate (clientAuth) signed by the trusted CA
- ``rogue-root.pem``, ``rogue-client.pem/.key`` client certificate signed by an *untrusted* CA

Keys are unencrypted PKCS#8 PEM (Granian requires PKCS#8). This is test material only.

Usage:
    python pki.py init [--dir certs] [--no-server]
    python pki.py issue-server [--dir certs] [--days 47]
"""

from __future__ import annotations

import argparse
import datetime as dt
import ipaddress
import os
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _key() -> ec.EllipticCurvePrivateKey:
    return ec.generate_private_key(ec.SECP256R1())


def _name(cn: str) -> x509.Name:
    return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])


def _key_pem(key: ec.EllipticCurvePrivateKey) -> bytes:
    return key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )


def _write(path: Path, data: bytes, mode: int = 0o644) -> None:
    """Atomic write: readers never see a half-written file."""
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def make_ca(cn: str) -> tuple[x509.Certificate, ec.EllipticCurvePrivateKey]:
    key = _key()
    now = _now()
    cert = (
        x509.CertificateBuilder()
        .subject_name(_name(cn))
        .issuer_name(_name(cn))
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(minutes=5))
        .not_valid_after(now + dt.timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .sign(key, hashes.SHA256())
    )
    return cert, key


def issue(
    ca_cert: x509.Certificate,
    ca_key: ec.EllipticCurvePrivateKey,
    cn: str,
    *,
    server: bool,
    days: int,
) -> tuple[x509.Certificate, ec.EllipticCurvePrivateKey]:
    key = _key()
    now = _now()
    builder = (
        x509.CertificateBuilder()
        .subject_name(_name(cn))
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(minutes=5))
        .not_valid_after(now + dt.timedelta(days=days))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage(
                [ExtendedKeyUsageOID.SERVER_AUTH if server else ExtendedKeyUsageOID.CLIENT_AUTH]
            ),
            critical=False,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(
            x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False
        )
    )
    if server:
        builder = builder.add_extension(
            x509.SubjectAlternativeName(
                [x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
            ),
            critical=False,
        )
    return builder.sign(ca_key, hashes.SHA256()), key


def _pem(cert: x509.Certificate) -> bytes:
    return cert.public_bytes(serialization.Encoding.PEM)


def _load_root(directory: Path) -> tuple[x509.Certificate, ec.EllipticCurvePrivateKey]:
    cert = x509.load_pem_x509_certificate((directory / "root.pem").read_bytes())
    key = serialization.load_pem_private_key((directory / "root.key").read_bytes(), password=None)
    assert isinstance(key, ec.EllipticCurvePrivateKey)
    return cert, key


def issue_server(directory: Path, days: int = 47) -> x509.Certificate:
    """(Re)issue the server certificate; ``server.version`` is written last (reload trigger)."""
    root_cert, root_key = _load_root(directory)
    cert, key = issue(root_cert, root_key, "localhost", server=True, days=days)
    _write(directory / "server.key", _key_pem(key), 0o600)
    # The served file contains the leaf followed by the issuer (a real chain).
    _write(directory / "server.pem", _pem(cert) + _pem(root_cert))
    _write(directory / "server.version", format(cert.serial_number, "x").encode())
    return cert


def init(directory: Path, *, with_server: bool = True) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    root_cert, root_key = make_ca("Spike Trusted Root")
    _write(directory / "root.pem", _pem(root_cert))
    _write(directory / "root.key", _key_pem(root_key), 0o600)

    client_cert, client_key = issue(root_cert, root_key, "spike-client", server=False, days=30)
    _write(directory / "client.pem", _pem(client_cert))
    _write(directory / "client.key", _key_pem(client_key), 0o600)

    rogue_cert, rogue_key = make_ca("Spike Rogue Root")
    _write(directory / "rogue-root.pem", _pem(rogue_cert))
    rc_cert, rc_key = issue(rogue_cert, rogue_key, "rogue-client", server=False, days=30)
    _write(directory / "rogue-client.pem", _pem(rc_cert))
    _write(directory / "rogue-client.key", _key_pem(rc_key), 0o600)

    for name in ("server.pem", "server.key", "server.version"):
        (directory / name).unlink(missing_ok=True)
    if with_server:
        issue_server(directory)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    p_init = sub.add_parser("init")
    p_init.add_argument("--dir", type=Path, default=Path("certs"))
    p_init.add_argument("--no-server", action="store_true", help="do not create the server cert yet")
    p_srv = sub.add_parser("issue-server")
    p_srv.add_argument("--dir", type=Path, default=Path("certs"))
    p_srv.add_argument("--days", type=int, default=47)
    args = parser.parse_args()
    if args.command == "init":
        init(args.dir, with_server=not args.no_server)
    else:
        cert = issue_server(args.dir, args.days)
        print(f"server certificate issued, serial {cert.serial_number:x}")


if __name__ == "__main__":
    main()

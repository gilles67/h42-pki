"""Build the ASGI TLS extension (https://asgi.readthedocs.io/en/latest/specs/tls.html).

Used by the custom Uvicorn protocol to expose the client certificate to the application under
``scope["extensions"]["tls"]``, the place a spec-compliant ASGI server would put it.
"""

from __future__ import annotations

import ssl
from typing import Any

from cryptography import x509

# TLS versions as defined by the ASGI TLS extension (IANA protocol version numbers).
_TLS_VERSIONS = {"TLSv1.2": 0x0303, "TLSv1.3": 0x0304}


def tls_extension(ssl_object: ssl.SSLObject) -> dict[str, Any]:
    """Return the ``tls`` extension dict for one TLS connection."""
    leaf_der = ssl_object.getpeercert(binary_form=True)
    chain_pem: list[str] = []
    client_cert_name: str | None = None
    if leaf_der:
        # get_verified_chain() exists on SSLObject from Python 3.13 (leaf first, then issuers).
        get_chain = getattr(ssl_object, "get_verified_chain", None)
        ders = list(get_chain()) if get_chain is not None else [leaf_der]
        chain_pem = [ssl.DER_cert_to_PEM_cert(der) for der in ders]
        client_cert_name = x509.load_der_x509_certificate(leaf_der).subject.rfc4514_string()
    return {
        "server_cert": None,
        "client_cert_chain": chain_pem,
        "client_cert_name": client_cert_name,
        # With CERT_OPTIONAL a certificate that fails verification aborts the handshake,
        # so a connection that reached the application never carries an error.
        "client_cert_error": None,
        "tls_version": _TLS_VERSIONS.get(ssl_object.version() or ""),
        "cipher_suite": None,
    }

"""Uvicorn HTTP protocol that exposes the client certificate to the ASGI application.

Uvicorn does not implement the ASGI TLS extension. This subclass wraps the application *per
connection*: once the TLS handshake is done (asyncio calls ``connection_made`` after it), it reads
the peer certificate from the transport and adds ``scope["extensions"]["tls"]`` to every request
of that connection. Plain HTTP connections are left untouched.
"""

from __future__ import annotations

import asyncio
from typing import Any

from uvicorn.protocols.http.h11_impl import H11Protocol

from tls_scope import tls_extension


def _with_tls(app: Any, tls: dict[str, Any]) -> Any:
    async def wrapped(scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] in ("http", "websocket"):
            scope = dict(scope)
            scope["extensions"] = {**(scope.get("extensions") or {}), "tls": tls}
        await app(scope, receive, send)

    return wrapped


class TLSAwareH11Protocol(H11Protocol):
    def connection_made(self, transport: asyncio.Transport) -> None:  # type: ignore[override]
        super().connection_made(transport)
        ssl_object = transport.get_extra_info("ssl_object")
        if ssl_object is not None:
            self.app = _with_tls(self.app, tls_extension(ssl_object))

# h42-tls-spike

Expérience autonome, **sans lien avec le code de h42-pki**, pour valider deux hypothèses avant de les
inscrire dans l'architecture :

1. **Un lanceur maison** peut faire tourner, dans **un seul processus**, un serveur HTTP et un serveur
   HTTPS sur la même application ASGI, démarrer le HTTPS **après coup** (quand l'AC a émis son
   certificat) et **renouveler le certificat à chaud**, sans reverse-proxy ni redémarrage.
2. Le **certificat client** (mTLS, indispensable pour EST) peut **arriver jusqu'à l'application**,
   avec Uvicorn ou avec Granian.

Tout le matériel cryptographique est généré à la volée (PKI jetable) ; rien n'est réutilisable tel quel.

## Contenu

| Fichier | Rôle |
|---|---|
| `pki.py` | PKI de test : AC de confiance, certificat serveur (SAN `localhost`, `127.0.0.1`), certificat client, et un client signé par une **AC inconnue** |
| `app.py` | Application ASGI minimale, sans framework. `GET /whoami` renvoie ce que l'application voit de la connexion, notamment `scope["extensions"]["tls"]`. `GET /admin` n'est servi qu'en HTTPS |
| `tls_scope.py` | Construit l'extension ASGI standard `tls` (`client_cert_chain`, `client_cert_name`, `tls_version`…) à partir de la connexion TLS |
| `uvicorn_tls.py` | Protocole HTTP Uvicorn personnalisé qui injecte cette extension dans chaque requête d'une connexion TLS (Uvicorn ne le fait pas lui-même) |
| `launcher_uvicorn.py` | **Le lanceur maison** : 2 serveurs Uvicorn dans une boucle asyncio, mTLS optionnel (`CERT_OPTIONAL`), démarrage différé du HTTPS, rechargement à chaud du certificat, chargement du certificat et de la clé depuis la mémoire (via un dossier temporaire privé supprimé aussitôt) |
| `probe_granian_embed.py` | Sonde du mode « embarqué » de Granian : HTTP + HTTPS dans un seul processus ? |
| `run_tests.py` | Lance tous les scénarios et produit un rapport Markdown |
| `Dockerfile` | Exécution complète (Uvicorn + Granian) sous Linux |

## Lancer l'expérience

### Avec Docker (recommandé, seul moyen d'avoir les scénarios Granian)

```bash
docker build -t h42-tls-spike .
docker run --rm -v "$PWD/out:/spike/out" h42-tls-spike     # rapport dans out/results.md
```

Même chose avec **Python 3.12**, la version de h42-pki :

```bash
docker build --build-arg PYTHON=3.12 -t h42-tls-spike:py312 .
docker run --rm h42-tls-spike:py312
```

### Sans Docker (Linux ou macOS)

```bash
uv run --with cryptography --with uvicorn --with granian python run_tests.py --report results.md
```

Sous Windows, passer par Docker : le script arrête les serveurs par signal (`SIGTERM`).

### À la main

```bash
python pki.py init --dir certs --no-server          # PKI sans certificat serveur
python launcher_uvicorn.py --certs certs --wait-for-cert &
python pki.py issue-server --dir certs              # le HTTPS démarre tout seul
curl -s http://127.0.0.1:8080/whoami
curl -s --cacert certs/root.pem --cert certs/client.pem --key certs/client.key https://127.0.0.1:8443/whoami
python pki.py issue-server --dir certs              # renouvellement à chaud
```

## Scénarios

**Uvicorn + lanceur maison (U1 à U14)** : attendus en `PASS`, le code de sortie est non nul sinon.
HTTP seul avant tout certificat, HTTPS ouvert dès que le certificat existe, séparation des routes
selon le port, mTLS optionnel, certificat client visible dans `scope["extensions"]["tls"]`, chaîne
vérifiée du client, refus d'un client signé par une AC inconnue, renouvellement à chaud (y compris
pour une connexion déjà ouverte), un seul processus, arrêt propre.

**Granian (G0 à G5)** : ce sont des **observations**, pas des tests. Elles ne font jamais échouer
l'exécution.
- **G1** : avec `--ssl-client-verify`, un client **sans** certificat est-il accepté ? EST en a besoin,
  pour l'authentification HTTP Basic sur le même port.
- **G2** : **la question clé**. Le certificat client est-il visible par l'application ?
- **G3** : un certificat d'AC inconnue est-il refusé ?
- **G4** : sans `--ssl-client-verify`, un certificat présenté est-il transmis ?
- **G5** : le mode embarqué permet-il HTTP + HTTPS dans un seul processus ?

## Résultats obtenus pendant la préparation (Uvicorn seulement)

Exécution du 2026-11-22, Python 3.13.18, uvicorn 0.54.0, cryptography 50.0.1 (Linux). Granian n'était
pas installable dans cet environnement.

| # | Scénario | Résultat |
|---|---|---|
| U1 | HTTP démarre seul, avant tout certificat serveur | PASS |
| U2 | HTTPS fermé tant qu'il n'y a pas de certificat | PASS |
| U3 | HTTPS démarre dès que le certificat existe (sans redémarrage) | PASS |
| U4 | HTTP : schéma http, pas d'extension tls | PASS |
| U5 | Séparation des routes : /admin refusé en HTTP | PASS |
| U6 | Séparation des routes : /admin servi en HTTPS | PASS |
| U7 | HTTPS sans certificat client accepté (mTLS optionnel) | PASS |
| U8 | Certificat client de confiance visible dans `scope['extensions']['tls']` | PASS |
| U9 | Chaîne vérifiée du client transmise (Python ≥ 3.13 : feuille + AC) | PASS |
| U10 | Certificat client d'une AC inconnue refusé | PASS |
| U11 | Renouvellement à chaud : les nouvelles connexions reçoivent le nouveau certificat | PASS |
| U12 | Une connexion ouverte avant le renouvellement continue de fonctionner | PASS |
| U13 | Les deux ports sont servis par un seul processus | PASS |
| U14 | Arrêt propre des deux serveurs sur SIGTERM | PASS |

Contrôle croisé : `openssl s_client` avec certificat client obtient la même réponse que le test (`client_cert_name = CN=spike-client`).

## Points d'attention relevés

- **Chaîne du client** : `SSLObject.get_verified_chain()` n'existe qu'à partir de **Python 3.13**.
  En 3.12, seul le certificat feuille du client est disponible (ce qui suffit pour EST). Le scénario U9
  s'adapte à la version.
- **Point d'appui sur Uvicorn** : le protocole personnalisé hérite de `H11Protocol` (API interne
  d'Uvicorn) et le contexte TLS passe par `ssl_context_factory` (disponible dans Uvicorn 0.54 ; un
  repli existe pour les versions plus anciennes). À épingler et tester à chaque mise à jour d'Uvicorn.
- **Rechargement à chaud** : il repose sur le fait qu'OpenSSL lit le certificat du `SSLContext` à
  chaque nouvelle connexion. Les connexions déjà ouvertes gardent l'ancien certificat jusqu'à leur
  fermeture, ce qui est le comportement souhaité.
- **Fichiers temporaires** : le module `ssl` de Python ne charge un certificat que depuis des fichiers.
  Ils sont écrits dans un dossier privé (`0700`, clé en `0600`) et supprimés juste après le
  chargement.
- **HTTP/1.1 seulement** : le lanceur utilise le protocole `h11` d'Uvicorn.

"""Home-made launcher: one process, one asyncio loop, two Uvicorn servers (HTTP + HTTPS).

What it demonstrates:

1. HTTP and HTTPS listeners served by the same application in the same process.
2. Optional mTLS (``CERT_OPTIONAL``): clients may connect with or without a certificate; a
   certificate that does not chain to the trusted CA aborts the handshake.
3. The client certificate reaches the application in ``scope["extensions"]["tls"]``
   (custom protocol, see ``uvicorn_tls.py``).
4. Delayed HTTPS start: with ``--wait-for-cert`` the HTTPS listener only starts once a server
   certificate exists (in h42-pki: once the CA is active and has issued it).
5. Hot reload: when ``server.version`` changes, the certificate is reloaded into the *same*
   ``SSLContext``; new connections get the new certificate, no restart.
6. Certificate and key loaded from bytes (in h42-pki they come from the database): Python's ssl
   module only loads from files, so they go through a private temporary directory deleted at once.

Usage:
    python launcher_uvicorn.py --certs certs --http-port 8080 --https-port 8443 [--wait-for-cert]
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import shutil
import signal
import ssl
import tempfile
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path

import uvicorn

from app import app
from uvicorn_tls import TLSAwareH11Protocol

log = logging.getLogger("launcher")


# --- certificate source (stands for the database in h42-pki) ---------------------------------


class CertSource:
    def __init__(self, directory: Path) -> None:
        self.directory = directory

    def version(self) -> str | None:
        path = self.directory / "server.version"
        return path.read_text().strip() if path.exists() else None

    def read(self) -> tuple[bytes, bytes, bytes]:
        """Return (certificate chain PEM, private key PEM, client trust anchor PEM)."""
        return (
            (self.directory / "server.pem").read_bytes(),
            (self.directory / "server.key").read_bytes(),
            (self.directory / "root.pem").read_bytes(),
        )


# --- SSL context --------------------------------------------------------------------------


def load_cert_chain_from_bytes(ctx: ssl.SSLContext, chain_pem: bytes, key_pem: bytes) -> None:
    """Load a certificate and key held in memory into ``ctx``.

    ``SSLContext.load_cert_chain`` only reads files: write them into a private temporary
    directory (0700, key 0600), load, delete. Nothing persists on disk.
    """
    directory = tempfile.mkdtemp(prefix="h42-tls-")
    try:
        cert_path = os.path.join(directory, "chain.pem")
        key_path = os.path.join(directory, "key.pem")
        fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            os.write(fd, key_pem)
        finally:
            os.close(fd)
        with open(cert_path, "wb") as f:
            f.write(chain_pem)
        ctx.load_cert_chain(cert_path, key_path)
    finally:
        shutil.rmtree(directory, ignore_errors=True)


def build_server_context(chain_pem: bytes, key_pem: bytes, client_ca_pem: bytes) -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    load_cert_chain_from_bytes(ctx, chain_pem, key_pem)
    # Optional client certificate: requested, verified if presented, not required.
    ctx.verify_mode = ssl.CERT_OPTIONAL
    ctx.load_verify_locations(cadata=client_ca_pem.decode())
    ctx.set_alpn_protocols(["http/1.1"])
    return ctx


# --- servers --------------------------------------------------------------------------------


class EmbeddedServer(uvicorn.Server):
    """Uvicorn server that leaves signal handling to the launcher (two servers, one process)."""

    @contextmanager
    def capture_signals(self) -> Generator[None, None, None]:
        yield

    def install_signal_handlers(self) -> None:  # older Uvicorn versions
        pass


def make_server(host: str, port: int, ssl_context: ssl.SSLContext | None) -> EmbeddedServer:
    kwargs: dict[str, object] = {
        "app": app,
        "host": host,
        "port": port,
        "http": TLSAwareH11Protocol,
        "lifespan": "off",
        "log_level": "warning",
    }
    if ssl_context is not None and "ssl_context_factory" in uvicorn.Config.__init__.__code__.co_varnames:
        kwargs["ssl_context_factory"] = lambda _config, _default: ssl_context
    config = uvicorn.Config(**kwargs)  # type: ignore[arg-type]
    if ssl_context is not None and "ssl_context_factory" not in kwargs:
        # Older Uvicorn: no factory hook, inject the context after load().
        config.load()
        config.ssl = ssl_context
    return EmbeddedServer(config)


async def run(certs: Path, host: str, http_port: int, https_port: int, wait_for_cert: bool, interval: float) -> None:
    source = CertSource(certs)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:  # Windows
            signal.signal(sig, lambda *_: loop.call_soon_threadsafe(stop.set))

    servers: list[EmbeddedServer] = []
    tasks: list[asyncio.Task[None]] = []

    http_server = make_server(host, http_port, None)
    servers.append(http_server)
    tasks.append(asyncio.create_task(http_server.serve()))
    log.warning("HTTP listening on %s:%d", host, http_port)

    async def https_supervisor() -> None:
        # 1. wait for a server certificate (delayed start)
        while source.version() is None:
            if not wait_for_cert:
                raise SystemExit("no server certificate and --wait-for-cert not given")
            log.warning("HTTPS waiting for a server certificate...")
            try:
                await asyncio.wait_for(stop.wait(), timeout=interval)
                return
            except TimeoutError:
                pass
        version = source.version()
        ctx = build_server_context(*source.read())
        https_server = make_server(host, https_port, ctx)
        servers.append(https_server)
        tasks.append(asyncio.create_task(https_server.serve()))
        log.warning("HTTPS listening on %s:%d (certificate %s)", host, https_port, version)
        # 2. hot reload on change
        while not stop.is_set():
            try:
                await asyncio.wait_for(stop.wait(), timeout=interval)
                return
            except TimeoutError:
                pass
            current = source.version()
            if current is not None and current != version:
                chain_pem, key_pem, _ = source.read()
                load_cert_chain_from_bytes(ctx, chain_pem, key_pem)
                log.warning("HTTPS certificate reloaded: %s -> %s", version, current)
                version = current

    supervisor = asyncio.create_task(https_supervisor())
    await stop.wait()
    for server in servers:
        server.should_exit = True
    supervisor.cancel()
    await asyncio.gather(supervisor, *tasks, return_exceptions=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--certs", type=Path, default=Path("certs"))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--http-port", type=int, default=8080)
    parser.add_argument("--https-port", type=int, default=8443)
    parser.add_argument("--wait-for-cert", action="store_true")
    parser.add_argument("--reload-interval", type=float, default=1.0)
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(name)s %(message)s")
    os.environ.setdefault("SPIKE_SERVER", "uvicorn")
    asyncio.run(run(args.certs, args.host, args.http_port, args.https_port, args.wait_for_cert, args.reload_interval))


if __name__ == "__main__":
    main()

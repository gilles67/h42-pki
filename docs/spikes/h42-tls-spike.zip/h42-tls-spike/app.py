"""Minimal ASGI application (no framework) used by both servers.

- ``GET /whoami``  : JSON describing the connection as the application sees it, including what
                     the server put in ``scope["extensions"]`` (the question of the spike).
- ``GET /admin``   : only served over HTTPS (route separation between the two listeners).
- anything else    : 404.

``SPIKE_SERVER`` (environment) names the server in the answer: ``uvicorn`` or ``granian``.
"""

from __future__ import annotations

import json
import os
from typing import Any


def _summarise_tls(ext: Any) -> Any:
    if not isinstance(ext, dict):
        return ext
    out = dict(ext)
    chain = out.get("client_cert_chain")
    if isinstance(chain, list):
        out["client_cert_chain"] = f"{len(chain)} certificate(s)"
    if out.get("server_cert"):
        out["server_cert"] = "<present>"
    return out


async def _send_json(send: Any, status: int, body: dict[str, Any]) -> None:
    data = json.dumps(body, default=str).encode()
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(data)).encode())],
        }
    )
    await send({"type": "http.response.body", "body": data})


async def app(scope: dict[str, Any], receive: Any, send: Any) -> None:
    if scope["type"] == "lifespan":
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                await send({"type": "lifespan.startup.complete"})
            elif message["type"] == "lifespan.shutdown":
                await send({"type": "lifespan.shutdown.complete"})
                return
    if scope["type"] != "http":
        return

    scheme = scope.get("scheme")
    path = scope.get("path")
    extensions = scope.get("extensions") or {}

    if path == "/admin":
        if scheme != "https":
            await _send_json(send, 404, {"detail": "admin is only served over HTTPS"})
            return
        await _send_json(send, 200, {"admin": True})
        return

    if path == "/whoami":
        await _send_json(
            send,
            200,
            {
                "server_software": os.environ.get("SPIKE_SERVER", "unknown"),
                "scheme": scheme,
                "server": scope.get("server"),
                "scope_keys": sorted(scope.keys()),
                "extension_keys": sorted(extensions.keys()) if isinstance(extensions, dict) else repr(extensions),
                "tls": _summarise_tls(extensions.get("tls")) if isinstance(extensions, dict) else None,
            },
        )
        return

    await _send_json(send, 404, {"detail": "not found"})
